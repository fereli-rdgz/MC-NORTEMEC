MC NORTEMEC - Página web

1. Abre esta carpeta en Visual Studio Code.
2. Abre index.html en el navegador.
3. Coloca el logo de la empresa en img/logo.png.
4. En index.html busca los comentarios:
   - CORREO OFICIAL
   - NÚMERO OFICIAL
   - UBICACIÓN
   - WHATSAPP
   y reemplaza esos datos cuando los tengas.
5. Para una vista en vivo, puedes usar la extensión Live Server de VS Code.

Archivos:
- index.html
- css/style.css
- js/script.js
- img/ (para logo e imágenes)
